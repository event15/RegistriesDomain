<?php
/**
 * Created by PhpStorm.
 * User: marek
 * Date: 17.07.15
 * Time: 12:23
 */

namespace Models\Registries\DepositRegistry;


class DepositRegistry
{

}