<?php
/**
 * Created by PhpStorm.
 * User: marek
 * Date: 17.07.15
 * Time: 12:22
 */

namespace Models\Registries\CarRegistry;


use Models\Registries\Registry;

class CarRegistry extends Registry
{
    /**
     * @var array
     */
    private $cars = array();

}